#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(tidyverse)
library(janitor)
library(dashboardthemes)

hours_of_sleep <- round(rnorm(40, mean = 6.5, sd = 1.5), digits = 1)
slope_size <- sample(c(4, 5, 6), 1)
assess_score <- round(30 + slope_size*hours_of_sleep, 0)
assess_score <- round(assess_score + rnorm(n = length(assess_score), mean = 0, sd = 5), 0)

data <- tibble(hours_of_sleep, assess_score)


# Define UI for application that draws a histogram
ui <- dashboardPage(
    dashboardHeader(),
    dashboardSidebar(
        sidebarMenu(
            menuItem("1: Drawing a Line", tabName = "line", icon = icon("console", lib = "glyphicon")),
            menuItem("2: Line with Residuals", tabName = "line_resid", icon = icon("console", lib = "glyphicon"))
        )
    ),
    dashboardBody(
        shinyDashboardThemes(
            theme = "grey_light"
        ),
        
        tabItems( # Tab content
            
            tabItem(tabName = "line",
                    fluidRow(
                        column(2),
                        column(8, box(title = "Change line intercept", width = "100%",
                                      sliderInput("intercept", label = "",
                                                  min = 0, max = 100, step = 1, round = 0, value = 50))),
                        column(2)
                    ),
                    fluidRow(
                        column(2),
                        column(8, box(title = "Change line slope", width = "100%",
                                      sliderInput("slope", label = "",
                                                  min = -10, max = 10, step = 0.25, round = 0, value = 0))),
                        column(2)
                    ),
                    fluidRow(
                        column(2),
                        column(8, box(title = "Update plot", width = "100%",
                                      actionButton("update_plot", label = "Update", icon = icon("sync"), width = "100%"))),
                        column(2)
                    ),
                    fluidRow(
                        column(2),
                        column(8, box(title = "Plot", width = "100%",
                                      plotOutput("plot", width = "100%", height = 500))),
                        column(2)
                    ),
                    fluidRow(
                        column(2),
                        column(8, box(title = "Actual Linear Regression", width = "100%",
                                      collapsible = TRUE,
                                      collapsed = TRUE,
                                      verbatimTextOutput("lm"))),
                        column(2)
                    )
                    
            ),
            
            tabItem(tabName = "line_resid",
                    fluidRow(
                        column(2),
                        column(8, box(title = "Plot with Residuals", width = "100%",
                                      plotOutput("plot2", width = "100%", height = 500))),
                        column(2)
                    )
                    
            )
            
        )
        
    )

)



server <- function(input, output) {

    v <- reactiveValues(plot = NULL, plot2 = NULL, predicted = NULL, lm = NULL)
    
    v$plot <- data %>%
        ggplot() +
        geom_point(aes(x = hours_of_sleep, y = assess_score), size = 3) +
        geom_abline(intercept = 50, slope = 0, size = 1.5) +
        ylab("Assessment Mark") +
        xlab("Average Hours of Sleep per night") +
        theme_minimal() +
        theme(text = element_text(size = 20))
    
    v$predicted <- 50 + 0*data$hours_of_sleep
    
    v$plot2 <- data %>%
        ggplot() +
        geom_segment(aes(x = hours_of_sleep, xend = hours_of_sleep,
                         y = assess_score, yend = v$predicted)) +
        geom_point(aes(x = hours_of_sleep, y = assess_score), size = 3) +
        geom_abline(intercept = 50, slope = 0, size = 1.5) +
        ylab("Assessment Mark") +
        xlab("Average Hours of Sleep per night") +
        theme_minimal() +
        theme(text = element_text(size = 20))
    
   observeEvent(input$update_plot, {
       
       v$plot <- data %>%
           ggplot() +
           geom_point(aes(x = hours_of_sleep, y = assess_score), size = 3) +
           geom_abline(intercept = input$intercept, slope = input$slope, size = 1.5) +
           ylab("Assessment Mark") +
           xlab("Average Hours of Sleep per night") +
           theme_minimal() +
           theme(text = element_text(size = 20))
       
       v$predicted <- input$intercept + input$slope*data$hours_of_sleep
       
       v$plot2 <- data %>%
           ggplot() +
           geom_segment(aes(x = hours_of_sleep, xend = hours_of_sleep,
                            y = assess_score, yend = v$predicted)) +
           geom_point(aes(x = hours_of_sleep, y = assess_score), size = 3) +
           geom_abline(intercept = input$intercept, slope = input$slope, size = 1.5) +
           ylab("Assessment Mark") +
           xlab("Average Hours of Sleep per night") +
           theme_minimal() +
           theme(text = element_text(size = 20))
    
   })
    
    output$plot <- renderPlot({
        
        if (is.null(v$plot)) return()
        v$plot
        
    })
    
    output$plot2 <- renderPlot({
        
        if (is.null(v$plot)) return()
        v$plot2
        
    })
    
    output$lm <- renderPrint({
        
        summary(lm(data, formula = assess_score ~ hours_of_sleep))
        
    })
    
    
}

# Run the application 
shinyApp(ui = ui, server = server)
