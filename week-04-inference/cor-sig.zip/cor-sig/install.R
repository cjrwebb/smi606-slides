install.packages("shiny")
install.packages("shinydashboard")
install.packages("tidyverse")
install.packages("janitor")